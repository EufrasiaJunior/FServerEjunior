<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
    integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"
    integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"
    integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
</script>
<!DOCTYPE html>

<head>

    <!-- Need to use datatables.net -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" />

    <!-- Mini-extra style to be apply to tables with the dataTable plugin  -->
    <style>
        .dataTable table tr {
            border: solid 1px black;
        }
    </style>

</head>

<body>
    <div class="container">
        <div style="padding: 50px">
            Bem vindo(a) {{ Auth::user()->nome }} - <a href="{{ url('logout') }}">Terminal Sessão</a>
        </div>

        <center>
            <h1>FServer eJúnior</h1>
        </center>

        @if (Auth::user()->admin == 1)
            <div class=" ">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                    Carregar Ficheiro
                </button>

                <!-- Modal -->
                <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog"
                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form method="post" enctype="multipart/form-data" action="{{ url('carregar') }}">
                                @csrf
                                <div class="modal-body">
                                    <label>Ficheiros*</label>
                                    <p><input required type="file" multiple name="ficheiros[]" /></p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary"
                                        data-dismiss="modal">Cancelar</button>
                                    <button type="submit" class="btn btn-primary">Confirmar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
        @endif
    </div>
    <hr>
    <div class="col-md-12">
        <h3>Ficheiros carregado(s):</h3>
        <div class="col-md-12 row">

        </div>
    </div>


    <table id="myTable" style="border:solid 1px black">
        <thead>
            <tr>
                <th>#</th>
                <th>FIcheiro</th>
                <th>Formado</th>
                <th>Tamanho</th>
                <th>Permissão</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            @foreach ($ficheiros as $ficheiro)
                <tr>
                    <td>{{ $i++ }}</td>
                    <td>{{ $ficheiro->nome }} &nbsp;[ <a target="empty" href="{{ url('ver', $ficheiro->id) }}">Ver</a> ]</td>
                    <td>{{ $ficheiro->formato }} MB</td>
                    <td>{{ $ficheiro->tamanho }}</td>
                    <td>Todos</td>
                    <td>

                        @if (Auth::user()->admin == 1)

                            <a style="color:red" href="{{ url('remover', $ficheiro->id) }}">Remover</a>
                        @endif
                    </td>
                </tr>
            @endforeach

        </tbody>
    </table>


    </div>

    <!-- Need to use datatables.net -->
    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>

    <script>
        $(document).ready(function() {

            //Apply the datatables plugin to your table
            $('#myTable').DataTable();

        });
    </script>

</body>

</html>
