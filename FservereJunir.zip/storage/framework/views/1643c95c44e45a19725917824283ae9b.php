<header>

<nav class="navbar navbar-expand-lg navbar-light">

	<div class="collapse navbar-collapse>" id="navbar">
        <a href="/" class="navbar-brand">
    </a>

    <ul class="navbar-nav">
        <li class="nav-item">
    <a href=""  class="nav-link"> Login </a>
    </li>

<li class="nav-item">
<a href="/login/cadastro"  class="nav-link"> Cadastrar </a>
</li>

<li class="nav-item">
<a href=""  class="nav-link"> Login </a>
</li>

</ul>
</nav>

</header><?php /**PATH C:\xampp\htdocs\fserver\resources\views/layouts/main.blade.php ENDPATH**/ ?>