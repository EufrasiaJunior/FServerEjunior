<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>

<header>

<nav class="navbar navbar-expand-lg navbar-light">

	<div class="collapse navbar-collapse>" id="navbar">
        <a href="/" class="navbar-brand">
    </a>

    <ul class="navbar-nav">
        <li class="nav-item">
    <a href=""  class="nav-link"> Login </a>
    </li>

<li class="nav-item">
<a href="/login/cadastro"  class="nav-link"> Cadastrar </a>
</li>

<li class="nav-item">
<a href=""  class="nav-link"> Login </a>
</li>

</ul>
</nav>

</header>

<?php $__currentLoopData = $cadastro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p> <?php echo e($users->name); ?> -- <?php echo e($users->email); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fserver\resources\views/welcometest.blade.php ENDPATH**/ ?>