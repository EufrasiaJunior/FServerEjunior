<?php

namespace App\Http\Controllers;
use App\Models\Ficheiro;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class FserverController extends Controller {
    function index() {
        $dados = [
            'ficheiros'=> Ficheiro::all(),
            'i'=>1
        ];

        return view( 'fserver.inicio', $dados );
    }
}
