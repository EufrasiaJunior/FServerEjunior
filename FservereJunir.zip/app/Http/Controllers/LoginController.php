<?php
namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class LoginController extends Controller {
    public function auth( Request $request ) {
        $credenciais = $request->validate( [
            'email' => [ 'required', 'email' ],
            'password' => [ 'required' ],
        ] );

        if ( Auth::attempt( $credenciais ) ) {
            $request->session()->regenererate();
            return redirect()->intended( 'dashbord' );
        } else {
            return redirect()->back()->with( 'erro', 'Usuário ou senha inválida.' );

        }

    }

    public function index( Request $request ) {
        if ( $request->all() ) {
            $credenciais = $request->validate( [
                'email' => [ 'required', 'email' ],
                'password' => [ 'required' ],
            ] );

            if ( Auth::attempt( $credenciais ) ) {
                $request->session()->regenerate();
                return redirect()->intended( 'admin' );
            }

        }

        return view( 'login.login' );
    }

    public function cadastro() {
        return view( login.cadastro );
    }
}
