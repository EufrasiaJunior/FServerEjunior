<?php
use App\Http\Controllers\LoginController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FserverController;
use Illuminate\Http\Request;
use App\Models\Ficheiro;

Route::match(["get","post"],'/', [LoginController::class, 'index'])->name("login");

Route::get("/logout",function (Request $request) {
   Auth::logout();
   return redirect("/");
});


Route::prefix("/admin")->middleware("auth")->group(function () {
    Route::get('/', [FserverController::class, 'index']);
});

Route::post("/carregar",function (Request $request) {
     $files= $request->file("ficheiros");

     foreach($files as $file){
        $encryptedData = Crypt::encrypt(file_get_contents($file));

        $filename = rand(1000, 9999) . time() . '.' . $file->extension();
        $ficheiro['ficheiro'] = $filename;
        $ficheiro['nome'] = addslashes($file->getClientOriginalName());
        $ficheiro['tamanho'] = round($file->getSize() / 1024 / 1024, 2);
        $ficheiro['formato'] = $file->extension();
        Storage::disk('local')->put('FServer/' . $filename, $encryptedData);
        Ficheiro::insert($ficheiro);

     }

     return redirect()->back();
});

Route::get("/remover/{id}",function ($id) {
    $file=Ficheiro::find($id);
    Ficheiro::where("id",$id)->delete();
    Storage::delete('FServer/' . $file->ficheiro);
    return redirect()->back();
});


Route::get("/ver/{id}",function ($id) {

        $doc = Ficheiro::where("id", $id)->first();
        $encryptedData = Storage::disk('local')->get('FServer/' . $doc->ficheiro);
        $decryptedData = Crypt::decrypt($encryptedData);
        header('Content-Type: ' . $doc->content_type);
        header('Content-Disposition: inline; filename="' . $doc->nome . '"');

        echo $decryptedData;
    });
