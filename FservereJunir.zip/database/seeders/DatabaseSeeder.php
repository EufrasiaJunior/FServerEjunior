<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // \App\Models\User::factory(10)->create();

        \App\Models\User::insert([
            'nome' => 'Admin Fserver',
            'email' => 'admin@fserver.local',
            'telefone' => '998009933',
            'admin' => 1,
            "password"=>bcrypt("fserver2023")
        ]);

         \App\Models\User::insert([
             'nome' => 'Eufrásia Júnior',
             'email' => 'eufrasia@fserver.local',
             'telefone' => '933223322',
             "password"=>bcrypt("fserver2023")
         ]);

         \App\Models\User::insert([
            'nome' => 'Marido Júnior',
            'email' => 'marido@fserver.local',
            'telefone' => '93543322',
            "password"=>bcrypt("fserver2023")
        ]);

        \App\Models\User::create([
            'nome' => 'Filho Júnior',
            'email' => 'filho@fserver.local',
            'telefone' => '93443300',
            "password"=>bcrypt("fserver2023")
        ]);

    }
}
